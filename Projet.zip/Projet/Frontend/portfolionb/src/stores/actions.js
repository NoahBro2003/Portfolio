export const SET_USERS = 'SET_USERS'
export const SET_USER = 'SET_USER'

export const SET_AUTH_USER = "SET_AUTH_USER"
export const LOGOUT_USER = 'LOGOUT_USER'