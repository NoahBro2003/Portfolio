"use client"
import React from "react";
import SignIn from "../components/SignIn";

function Login() {
  return (
    <div>
        <SignIn/>
    </div>
  );
}

export default Login;
