import React from 'react'

function TemoignageId() {
  return (
    <div className="content">
      <div>Specific temoignage page</div>
    </div>
  )
}

export default TemoignageId