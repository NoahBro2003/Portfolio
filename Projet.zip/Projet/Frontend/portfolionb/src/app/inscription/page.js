import React from "react";
import "../rules.css";
import Link from "next/link";
import SignUp from "../components/SignUp";

function SignIn() {
  return (
    <div className="signup">
      <SignUp/>
    </div>
  );
}

export default SignIn;
