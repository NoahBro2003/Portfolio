import Acceuil from "./acceuil/page";

export default function Home() {
  return (
  <div>
      <Acceuil/>
    </div>
  );
}
